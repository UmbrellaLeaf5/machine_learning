import cv2
import numpy as np
import torch

from .core import RAFT, InputPadder, flow_vis


def vis_flow(img, flow):
    flow = flow_vis.flow_to_image(flow)
    img_flow = np.concatenate([img, flow], axis=1)
    return flow, img_flow


def get_model():
    model = torch.nn.DataParallel(RAFT({"small": False, "mixed_precision": False}))
    model.load_state_dict(
        torch.load(
            "raft/raft-things.pth",
            map_location=torch.device("cpu"),
        )
    )
    model = model.module
    model.eval()
    model = model.to(torch.device("cpu"))
    return model


def get_flow_estimation(model, image1, image2):
    original_shape = image1.shape
    with torch.no_grad():
        image1 = torch.from_numpy(image1).permute(2, 0, 1).float()[None]
        image2 = torch.from_numpy(image2).permute(2, 0, 1).float()[None]

        padder = InputPadder(image1.shape)
        image1, image2 = padder.pad(image1, image2)

        _, flow_up = model(image1, image2, iters=20, test_mode=True)
        flow_up = padder.unpad(flow_up[0])
        flow_up = flow_up.permute(1, 2, 0).cpu().numpy()
        flow_up = cv2.resize(
            flow_up,
            (original_shape[1], original_shape[0]),
            interpolation=cv2.INTER_LINEAR,
        )
        return flow_up
